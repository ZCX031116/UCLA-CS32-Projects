#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Board.h"
#include "Actor.h"
#include <sstream>
#include <iomanip>
#include <string>
using namespace std;

const int Empty = 0;
const int Squares = 1;
// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp
class Actor;
class PlayerAvatar;

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetPath);
	virtual int init();
	virtual int move();
	virtual void cleanUp();
	void displayGameText(int p1roll, int p1star, int p1coin, int p1vor, int bank, int p2roll, int p2star, int p2coin, int p2vor);
	bool checkSquare(int x, int y);
	int MaxX() { return edgeX; }
	int MaxY() { return edgeY; }
private:
	std::vector <Actor*> A;
	std::vector <PlayerAvatar* > P;
	int MAP[20][20];
	int edgeX;
	int edgeY;
	ostringstream oss;
};

#endif // STUDENTWORLD_H_
