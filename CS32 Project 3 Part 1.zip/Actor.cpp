#include "Actor.h"
#include "StudentWorld.h"

bool PlayerAvatar::checkNext(int dir)
{
	int newX = getX(), newY = getY();
	switch (dir)
	{
	case left:  newX -= 2; break;
	case right: newX += 2; break;
	case up:    newY += 2; break;
	case down:  newY -= 2; break;
	}
	if (newX > getWorld()->MaxX() || newX<0 || newY> getWorld()->MaxY() || newY < 0)
		return false;
	newX /= 16;
	newY /= 16;
	return getWorld()->checkSquare(newX, newY);
}
int PlayerAvatar::getRoll()
{
	if (ticks_to_move % 8 == 0)
		roll = ticks_to_move;
	else
		roll = ticks_to_move / 8 + 1;
	return roll;
}
void PlayerAvatar::doSomething()
{
	if (m_state == waiting_to_roll)
	{
		int action = getWorld()->getAction(1);
		//std::cout << "action: " << action << " " << ACTION_ROLL << std::endl;
		if (action == ACTION_ROLL)
		{
			
			int die_roll = randInt(1, 10);
			ticks_to_move = die_roll * 8;
			m_state = walking;
			//getWorld()->displayGameText(die_roll, getStar(), getCoin(), getVor(), 0, 0, 0, 0, 0);
		}
		else
			return;
	}
	if (m_state == walking)
	{
		//	if the Avatar can't continue moving forward in its current direction:
		if (!checkNext(walk_dir))
		{
			//i.Update the Avatar's walk direction so it can turn to face a new direction perpendicular to the current walking direction.
			//1. Always prefer up over down if both options are available.
			//2. Always prefer right over left if both options are available.
			if (walk_dir == right || walk_dir == left)
			{
				if (checkNext(up))
				{
					walk_dir = up;
					setDirection(right);
				}
				else if (checkNext(down))
				{
					walk_dir = down;
					setDirection(right);
				}
			}
			else if (walk_dir == up || walk_dir == down)
			{
				if (checkNext(right))
				{
					walk_dir = right;
					setDirection(right);
				}
				else if (checkNext(left))
				{
					walk_dir = left;
					setDirection(left);
				}
			}
		}
		//	ii.Update the direction the Avatar's sprite faces based on the walk direction: if the walk direction is left, the sprite direction must be
			//180 degrees; for all other walk directions, the sprite direction must be 0 degrees.
		//	iii.Continue with step d.
		//	d.Move two pixels in the walk direction.
		moveAtAngle(walk_dir, 2);
		ticks_to_move--;
		//getWorld()->displayGameText(ticks_to_move/8, getStar(), getCoin(), getVor(), 0, 0, 0, 0, 0);
		//e.Decrement the ticks_to_move count by 1.
		//f.If ticks_to_move is 0 then:
		if (ticks_to_move == 0)
			m_state = waiting_to_roll;
		//std::cout << "walked<" << std::endl;
	}
	//std::cout << "asked" << std::endl;
	return;
}

void CoinSquare::doSomething()
{
	if (ifalive() == dead)
	{
		//std::cout << "asked" << std::endl;
		return;
	}
	//std::cout << "asked" << std::endl;
	return;
}
// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp
