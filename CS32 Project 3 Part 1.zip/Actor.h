#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameConstants.h"
// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

const int waiting_to_roll = 0;
const int walking = 1;
const int dead = 0;
const int living = 1;

class StudentWorld;

class Actor : public GraphObject
{
public:
	Actor(int imageID, int startX, int startY, StudentWorld* m, int dir, int depth, double size) : 
	m_world(m), GraphObject(imageID, startX*16, startY*16,dir, depth, size)
	{
		//std::cout << "imageID: " << imageID << std::endl;
		m_alive = living;
	}
	virtual void doSomething() = 0;
	int ifalive()
	{
		return m_alive;
	}
	StudentWorld* getWorld()
	{
		return m_world;
	}
private:
	int m_alive;
	StudentWorld* m_world;
};
class Vortexes : public Actor
{
public:

private:

};
class PlayerAvatar : public Actor
{
public:
	PlayerAvatar(int startX, int startY, StudentWorld* m, int dir = right, int depth = 0, double size = 1.0) : 
	roll(0),walk_dir(right), m_coins(0), m_stars(0), m_vortexNum(0), ticks_to_move(0), m_state(waiting_to_roll), Actor(IID_PEACH, startX, startY, m, dir, depth, size) {}
	bool checkNext(int dir);
	virtual void doSomething();
	int getStar() { return m_stars; }
	int getCoin() { return m_coins; }
	int getVor() { return m_vortexNum; }
	int getRoll();
	
private:
	int walk_dir, m_coins, m_stars, m_vortexNum, ticks_to_move, m_state, roll;
	//std::vector <Vortexes*> m_vortex;

};
class Square : public Actor
{
public:
	Square(int imageID, int startX, int startY, StudentWorld* m, int dir, int depth , double size ) : 
	Actor(imageID, startX, startY, m, dir, depth, size) {}

private:

};
class CoinSquare : public Square
{
public:
	CoinSquare(int startX, int startY, StudentWorld* m, int dir = right, int depth = 1, double size = 1.0) : 
	Square(IID_BLUE_COIN_SQUARE, startX, startY, m, dir, depth, size) {}
	int Activate()
	{
		return 3; //coins + 3
	}
	virtual void doSomething();
private:

};
#endif // ACTOR_H_
