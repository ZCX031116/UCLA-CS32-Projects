#include "StudentWorld.h"
#include "GameConstants.h"

#include <string>
#include<algorithm>
using namespace std;

class Actor;
class PlayerAvatar;
class CoinSquare;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath) : GameWorld(assetPath)
{
    edgeX = edgeY = 0;

    for (int i = 0; i < BOARD_WIDTH; i++)
        for (int j = 0; j < BOARD_HEIGHT; j++)
            MAP[i][j] = Empty;
}

int StudentWorld::init()
{
    Board bd;
    string board_file = assetPath() + "board01.txt";
    Board::LoadResult result = bd.loadBoard(board_file);
    if (result == Board::load_fail_file_not_found)
    {
      //  cerr << "Could not find board01.txt data file\n";
        return GWSTATUS_BOARD_ERROR;
    }
    else if (result == Board::load_fail_bad_format)
    {
      //  cerr << "Your board was improperly formatted\n";
        return GWSTATUS_BOARD_ERROR;
    }
    else if (result == Board::load_success)
    {
     //   cerr << "Successfully loaded board\n";
        for (int i = 0; i < BOARD_WIDTH; i++)
        {
            for (int j = 0; j < BOARD_HEIGHT; j++)
            {
                Board::GridEntry ge = bd.getContentsOf(i, j);
                PlayerAvatar* p;
                CoinSquare* c;
                switch (ge)
                {
                case Board::empty:
                    // cout << "Location" << i << " " << j << " is empty\n";
                    break;
                case Board::boo:
                    // cout << "Location" << i << " " << j << " has a Boo and a blue coin square\n";
                    break;
                case Board::bowser:
                    // cout << "Location" << i << " " << j << " has a Bowser and a blue coin square\n";
                    break;
                case Board::player:
                    p = new PlayerAvatar(i, j, this);
                    c = new CoinSquare(i, j, this);
                    A.push_back(c);
                    P.push_back(p);
                    MAP[i][j] = Squares;
                    edgeX = max(edgeX, p->getX());
                    edgeY = max(edgeY, p->getY());
                   // cout << "Location" << p->getX() << " " << p->getY() << " has Peach & Yoshi and a blue coin square\n";
                    break;
                case Board::blue_coin_square:
                    c = new CoinSquare(i, j, this);
                    A.push_back(c);
                    MAP[i][j] = Squares;
                    edgeX = max(edgeX, c->getX());
                    edgeY = max(edgeY, c->getY());
                  //  cout << "Location" << c->getX() << " " << c->getY() << " has a blue coin square\n";
                    break;
                case Board::red_coin_square:
                    // cout << "Location" << i << " " << j << " has a red coin square\n";
                    break;
                }
            }
        }
    }
 /*   cout << "Peach: " << P[0]->getX() << " " << P[0]->getY() << " " << P[0]->isVisible() << endl;
   for(int i = 0; i < A.size(); i++)
    {
       cout << "Blue Coin " << i + 1 << ": " << A[i]->getX() << " " << A[i]->getY() << " " << A[i]->isVisible() << endl;
    }*/
   
	startCountdownTimer(99);  // this placeholder causes timeout after 5 seconds
    
    return GWSTATUS_CONTINUE_GAME;
}
bool StudentWorld::checkSquare(int x, int y) {
    if (x > 15 || y > 15 || x < 0 || y < 0)
        return false;
    return MAP[x][y] == Squares;
}
void StudentWorld::displayGameText(int p1roll, int p1star, int p1coin, int p1vor, int bank, int p2roll, int p2star, int p2coin, int p2vor) {
    ostringstream oss;
    oss << "P1 Roll: " << p1roll << " Stars: " << p1star << " $$: " << p1star;
    if (p1vor > 0)
        oss << " VOR";
    oss<<" | Time: "<< timeRemaining()<<" | Bank: "<<bank<<" | P2 Roll: "<<p2roll<< " Stars: " << p2star << " $$: " << p2star;
    if (p2vor > 0)
        oss << " VOR ";
    string s = oss.str();
    setGameStatText(s);
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit ESC.
    // Notice that the return value GWSTATUS_NOT_IMPLEMENTED will cause our framework to end the game.
        // The term "actors" refers to all actors, e.g., Peach, Yoshi, 
        // baddies, squares, vortexes, etc.
        // Give each actor a chance to do something, incl. Peach and Yoshi
    for (int i = 0; i < P.size(); i++)
        if (P[i]->ifalive() == living)
        {
            //cout<<"asked"<<endl;
            P[i]->doSomething();
           // cout << P[i]->getX() << " " << P[i]->getY() << endl;
        }
    for (int i = 0; i < A.size(); i++)
        if (A[i]->ifalive() == living)
        {
            //cout << "asked" << endl;
            A[i]->doSomething();
        }
            
    vector <Actor*>::iterator it;
    for (it = A.begin(); it != A.end();)
    {
        if ((*it)->ifalive() != living)
        {
            delete (*it);
            A.erase(it);
        }
        it++;
    }
    // Update the Game Status Line
    displayGameText(P[0]->getRoll(), P[0]->getStar(), P[0]->getCoin(), P[0]->getVor(), 0, 0, 0, 0, 0);// update the coins/stars stats text at screen top


    if (timeRemaining() <= 0)
    {
        playSound(SOUND_GAME_FINISHED);
        //    if (yoshi won)
        //    {
         //       setFinalScore(yoshi_stars, yoshi_coins);
          //      return GWSTATUS_YOSHI_WON;
           // }
            // peach won

        setFinalScore(P[0]->getStar(), P[0]->getCoin());
        return GWSTATUS_PEACH_WON;
    }
      if (timeRemaining() <= 0)
      	return GWSTATUS_NOT_IMPLEMENTED;
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    while (!A.empty())
    {
        delete A.back();
        A.pop_back();
    }
    while (!P.empty())
    {
        delete P.back();
        P.pop_back();
    }
}